package com.cg.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.QMapper.ApplicationQMapper;
import com.cg.dto.Application;
import com.cg.dto.ProgramScheduled;
import com.cg.util.DBUtil;
import com.cg.util.MyStringDateUtil;

public class ApplicationDAOImpl implements ApplicationDAO{
	
	Connection con=null;

	public ApplicationDAOImpl() {
		
	}

	@Override
	public int addApplication(Application applicant) {
		int applicationId = 0;
		ResultSet rs = null;
		PreparedStatement pstmt = null;
		PreparedStatement appIdStatement = null;
		
		if (applicant != null) {
			
			try {
				java.sql.Date sqlDOB = MyStringDateUtil.fromLocalToSqlDate(applicant.getDateOfBirth());
				con= DBUtil.getConnection();
				pstmt = con.prepareStatement(ApplicationQMapper.INSERT);
				pstmt.setString(1, applicant.getFullName());
				pstmt.setDate(2, sqlDOB);
				pstmt.setString(3, applicant.getHighestQualification());
				pstmt.setInt(4, applicant.getMarksObtained());
				pstmt.setString(5, applicant.getGoals());
				pstmt.setString(6, applicant.getEmailId());
				pstmt.setString(7, applicant.getScheduledProgramId());
				int count = pstmt.executeUpdate();
				if (count > 0){
					appIdStatement = con.prepareStatement(ApplicationQMapper.CURR_APP_ID);
					rs=appIdStatement.executeQuery();
					if(rs.next())
					{
						applicationId=rs.getInt(1);
						System.out.println("Applicant Id is: "+applicationId);
					}
				}
				else {				
					System.out.println("Inserting applicant details failed ");
				}				
			}
			catch (SQLException | IOException e) 
			{
				System.out.println(e.getMessage());
			} 			
		}		
		return applicationId;
	}
	
	@Override
	public ArrayList<ProgramScheduled> getAllScheduledPrograms() {		
		ArrayList<ProgramScheduled> programScheduledList = new ArrayList<ProgramScheduled>();
		PreparedStatement pstmt = null;

		     try {
		    	con= DBUtil.getConnection();
				pstmt = con.prepareStatement(ApplicationQMapper.SELECT_ALL_PS);
				ResultSet rs = pstmt.executeQuery();
				System.out.println("ProgramId\t\t\tProgramName\t\t\tLocation\t\t\tStartDate\t\t\t\tEndDate\t\t\t\tSessionsPerWeek\n");
				while(rs.next()){
					System.out.println(rs.getString(1)+"\t\t\t\t"+rs.getString(2)+"\t\t\t\t"+rs.getString(3)+"\t\t\t\t"+rs.getDate(4)+"\t\t\t\t"+rs.getDate(5)+"\t\t\t\t"+rs.getInt(6));
				}
			} 
		     catch (SQLException | IOException e) {
				System.out.println(e.getMessage());
			} 
		return programScheduledList;
	}

	@Override
	public String applicationStatus(int ID) {		
		String status = null;
		PreparedStatement pstmt = null;				
		try {
			con= DBUtil.getConnection();
			pstmt = con.prepareStatement(ApplicationQMapper.STATUS_usingID);
			pstmt.setInt(1,ID);
			ResultSet resultset = pstmt.executeQuery();
			if(resultset.next())
			{
				status = resultset.getString(1);			
			}			
		} 
		catch (SQLException | IOException sqlException) {
			System.out.println(sqlException.getMessage());
		} 		
		return status;
	}

	@Override
	public ArrayList<String> getScheduledProgramId() {
		ArrayList<String> list = new ArrayList<String>();
		try{
			PreparedStatement pst = con.prepareStatement(ApplicationQMapper.SCH_PROGRAM_ID);
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				list.add(rs.getString(1));
			}	
		}		
		catch(Exception e){
			System.out.println("No Programs Found");
			System.out.println(e.getMessage());
		}
		return list;
	}
}