package com.cg.client;
import java.util.Scanner;

import com.cg.service.MACService;
import com.cg.service.MACServiceImpl;

public class MemberLoginMain {

	MACService service=null;
	public void Login()
	{
		int LoginAttempt=0;
		int choice=-1;
		service= new MACServiceImpl();
		Scanner sc = new Scanner(System.in);
		while(true)
		{
			if(LoginAttempt>2)
			{
				System.out.println("Too many Attempts! \n Exiting Application...");
				sc.close();
				System.exit(0);
			}
			else
			{
				System.out.println("You have "+(3-LoginAttempt)+" attempts remaining");
				System.out.println("Login Id: ");
				String login=sc.next();
				System.out.println("Password:");
				String pass=sc.next();
				
			}
		}
	}
}
