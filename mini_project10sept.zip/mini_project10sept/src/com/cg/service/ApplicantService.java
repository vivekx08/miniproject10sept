package com.cg.service;

import java.util.List;

import com.cg.dto.Application;
import com.cg.dto.ProgramScheduled;

public interface ApplicantService {

	List <ProgramScheduled> getAllScheduledPrograms();
	int addApplication(Application applicant);
	String applicationStatus(int ID);
}
