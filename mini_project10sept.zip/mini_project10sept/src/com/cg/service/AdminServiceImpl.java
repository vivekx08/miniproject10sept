package com.cg.service;

import java.io.IOException;
import java.sql.Date;
import java.util.ArrayList;

import com.cg.dao.AdminDAO;
import com.cg.dao.AdminDAOImpl;
import com.cg.dto.Application;
import com.cg.dto.ProgramOffered;
import com.cg.dto.ProgramScheduled;

public class AdminServiceImpl implements AdminService{

	AdminDAO adao = null;
	
	
	public AdminServiceImpl() throws IOException {
		super();
		adao = new AdminDAOImpl();
	}

	@Override
	public boolean checkLogin(String loginId, String password) {
		return adao.checkLogin(loginId, password);
	}

	@Override
	public void addProgram(ProgramOffered obj) {
		adao.addProgram(obj);
	}

	@Override
	public void deleteProgram(String programName) {
		adao.deleteProgram(programName);
	}

	@Override
	public void scheduleProgram(ProgramScheduled obj) {
		adao.scheduleProgram(obj);
	}

	@Override
	public ArrayList<ProgramScheduled> getScheduledProgram(Date startDate, Date endDate) {
		return adao.getScheduledProgram(startDate, endDate);
	}

	@Override
	public ArrayList<Application> getStatus(String status) {
		return adao.getStatus(status);
	}

}
