package com.cg.service;

import java.time.LocalDate;
import java.util.List;

import com.cg.dao.MACDAO;
import com.cg.dao.MACDAOImpl;
import com.cg.dto.Application;
import com.cg.dto.ProgramScheduled;

public class MACServiceImpl implements MACService{

	MACDAO dao=null;
	public MACServiceImpl() {
		super();
		dao=new MACDAOImpl();
	}

	@Override
	public List<ProgramScheduled> getAllScheduledPrograms() {
		return dao.getAllScheduledPrograms();
	}

	@Override
	public String updateStatus(String status, int id) {
		return dao.updateStatus(status, id);
	}

	@Override
	public String setInterviewDate(LocalDate date, int id) {
		return dao.setInterviewDate(date, id);
	}

	@Override
	public List<Application> showApplicationByStatus(String status) {
		return dao.showApplicationByStatus(status);
	}

}
