package com.cg.service;

import java.time.LocalDate;
import java.util.List;

import com.cg.dto.Application;
import com.cg.dto.ProgramScheduled;

public interface MACService {
	public List <ProgramScheduled> getAllScheduledPrograms();
	public String updateStatus(String status,int id);
	public String setInterviewDate(LocalDate date,int id);
	public List<Application> showApplicationByStatus(String status);
}
