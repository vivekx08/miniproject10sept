package com.cg.dao;

public interface UserDao {
	/*validateCredentials
	getRole()*/
}
