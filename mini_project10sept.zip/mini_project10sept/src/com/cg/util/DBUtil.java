package com.cg.util;

import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;


public class DBUtil {

	static String unm;
	static String pwd;
	static String url;
	static String driver;
	
	public static Connection getConnection() throws IOException
	{
		Connection con = null;
		
		Properties dbProps = getDBInfo();
		unm = dbProps.getProperty("dbUserName");
		pwd = dbProps.getProperty("dbPassword");
		url = dbProps.getProperty("dbUrl");
		driver = dbProps.getProperty("dbDriver");
		
		try 
		{
			System.out.println("before");
			con = DriverManager.getConnection(url, unm, pwd);
			System.out.println("Connection Established");
		}
		catch (SQLException e) 
		{

			e.printStackTrace();
		}
			
		
		return con;
	}
	
	public static Properties getDBInfo() throws IOException
	{
		FileReader fr = new FileReader("dbInfo.properties");
		
		Properties myProps = new Properties();
		myProps.load(fr);
		System.out.println("bb");
		return myProps;
		
	}
}




//import java.sql.Connection;
//import java.sql.DriverManager;
//
//
//public class DBUtil {
//	
//	static Connection con;
//	
//	static 
//	{
//		try
//		{
//			Class.forName("oracle.jdbc.driver.OracleDriver");
//			String url = "jdbc:oracle:thin:@10.51.103.201:1521:ORCL11G";
//		    String user = "Lab2Etrg30";
//			String passwd = "lab2eoracle";
//			con = DriverManager.getConnection(url,user,passwd);
//		}
//		catch(Exception e)
//		{
//			System.out.println(e.getMessage());
//		}
//	}
//	
//	public static Connection getConnection()
//	{
//		return con;
//	}
//
//}
