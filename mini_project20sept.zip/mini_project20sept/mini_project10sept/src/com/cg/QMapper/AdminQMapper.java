package com.cg.QMapper;

public interface AdminQMapper {
	public static final String DETAILS_usingROLE = "select login_id,password from users where role = admin";
	public static final String INSERT_PO = "insert into Programs_Offered values(?,?,?,?,?)";
	public static final String DELETE_PO = "delete Programs_Offered where ProgramName= ? "; 
	public static final String INSERT_PS = "insert into Programs_Scheduled  values(?,?,?,?,?,?)";
	public static final String GET_SCH_PROGRAM = "select * from Programs_Scheduled where start_date >= ? and end_date<= ? ";
	public static final String APPLICANT_BY_STATUS = "SELECT * FROM Application where status=?";
	public static final String PROGRAMNAME_fromPO = "select programname from programs_offered";
	public static final String GET_PROG_OFFERED = "select * from Programs_Offered";
}
