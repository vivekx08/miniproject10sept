package com.cg.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import com.cg.QMapper.MACDAOQMapper;
import com.cg.dto.Application;
import com.cg.dto.ProgramScheduled;
import com.cg.util.DBUtil;
import com.cg.util.MyStringDateUtil;

public class MACDAOImpl implements MACDAO {

	Connection con;
	PreparedStatement pstmt = null;

	public MACDAOImpl() {
	
	}

	public List<ProgramScheduled> getAllScheduledPrograms() {
		List<ProgramScheduled> programScheduledList = new ArrayList<>();

		try {
			con= DBUtil.getConnection();
			pstmt = con.prepareStatement(MACDAOQMapper.SELECT_ALL_PS);
			ResultSet resultSet = pstmt.executeQuery();
			while (resultSet.next()) {
				ProgramScheduled programScheduled = new ProgramScheduled();
				
				programScheduled.setScheduledProgramId(resultSet
						.getString(1));
				programScheduled.setProgramName(resultSet
						.getString(2));
				programScheduled.setLocation(resultSet.getString(3));
				programScheduled.setStartDate(resultSet.getDate(4));
				programScheduled.setEndDate(resultSet.getDate(5));
				programScheduled.setSessionsPerWeek(resultSet
						.getInt(6));
				programScheduledList.add(programScheduled);
			}
		} catch (SQLException | IOException e) {
			System.out.println(e.getMessage());
		}
		return programScheduledList;
	}

	@Override
	public String updateStatus(String status, int id) {
		int result = 0;
		try {
			con= DBUtil.getConnection();
			pstmt = con.prepareStatement(MACDAOQMapper.UPDATE_STATUS);
			pstmt.setString(1, status);
			pstmt.setInt(2, id);
			result = pstmt.executeUpdate();
		} catch (SQLException | IOException e) {
			System.out.println(e.getMessage());
		}
		if (result > 0) {
			return status;
		} else {
			return null;
		}

	}

	@Override
	public int setInterviewDate(LocalDate date, int id) {
		int result = 0;
		java.sql.Date sqlDate = java.sql.Date.valueOf(date);
		try {
			con= DBUtil.getConnection();
			pstmt = con.prepareStatement(MACDAOQMapper.SET_INTERVIEW);
			pstmt.setDate(1, sqlDate);
			pstmt.setInt(2, id);
			result = pstmt.executeUpdate();
		} catch (SQLException | IOException e) {
			System.out.println(e.getMessage());
		}
		return result;
	}

	@Override
	public List<Application> showApplicationByStatus(String status) {

		List<Application> applicantList = new ArrayList<Application>();
		try {
			con= DBUtil.getConnection();
			pstmt = con.prepareStatement(MACDAOQMapper.APPLICANT_BY_STATUS);
			pstmt.setString(1,status);
			ResultSet resultSet = pstmt.executeQuery();
			while (resultSet.next())
			{
				applicantList.add(new Application(resultSet.getInt(1),resultSet.getString(2),MyStringDateUtil.fromSqlToLocalDate(resultSet.getDate(3)),resultSet.getString(4),
						resultSet.getInt(5),resultSet.getString(6),resultSet.getString(7),resultSet.getString(8),resultSet.getString(9)));
			}			
		} 
		catch (SQLException | IOException e) {			
			System.out.println(e.getMessage());
		}		
		return applicantList;
	}

	@Override
	public List<Application> getAllApplications() {
		List<Application> list= new ArrayList<Application>();
		try {
			con= DBUtil.getConnection();
			pstmt = con.prepareStatement(MACDAOQMapper.ALL_APPLICATIONS);
			ResultSet resultSet = pstmt.executeQuery();
			while (resultSet.next())
			{
				list.add(new Application(resultSet.getInt(1),resultSet.getString(2),MyStringDateUtil.fromSqlToLocalDate(resultSet.getDate(3)),resultSet.getString(4),
						resultSet.getInt(5),resultSet.getString(6),resultSet.getString(7),resultSet.getString(8),resultSet.getString(9)));
			}			
		} 
		catch (SQLException | IOException e) {			
			System.out.println(e.getMessage());
		}
		return list;
	}

	@Override
	public String ReturnStatus(int id) {
		String status=null;
		String qry= "SELECT STATUS FROM APPLICATION WHERE APPLICATION_ID=?";
		try {
			con= DBUtil.getConnection();
			pstmt = con.prepareStatement(MACDAOQMapper.STATUS_usingID);
			pstmt.setInt(1, id);
			ResultSet resultSet = pstmt.executeQuery();
			resultSet.next();
			status=resultSet.getString(1);
		} 
		catch (SQLException | IOException e) {
			
			e.printStackTrace();
		}
		return status;
	}

}
