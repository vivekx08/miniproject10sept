package com.cg.service;

import java.util.ArrayList;
import java.util.List;

import com.cg.Exception.UASException;
import com.cg.dto.Application;
import com.cg.dto.ProgramScheduled;

public interface ApplicantService {

	List <ProgramScheduled> getAllScheduledPrograms();
	int addApplication(Application applicant) throws UASException;
	String applicationStatus(int ID);
	public ArrayList<String> getScheduledProgramId();
}
